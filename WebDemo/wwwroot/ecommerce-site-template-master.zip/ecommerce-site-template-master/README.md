## react-redux-template-for-ecommerce-site

A beautiful e-commerce template with flat design.

## Installation

*  Install yarn globally by `npm install yarn -g`
*  `yarn install`
*  `yarn start`

Open `localhost:8080` to open the app!

Demo - https://react-template-arshad.now.sh/
